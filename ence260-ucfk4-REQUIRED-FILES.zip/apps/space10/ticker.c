/** @file   ticker.c
    @author M. P. Hayes, UCECE
    @date   2 April 2007
    @brief 
*/

