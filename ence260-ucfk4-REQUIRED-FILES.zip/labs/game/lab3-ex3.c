#include "system.h"
#include "pacer.h"
#include "navswitch.h"
#include "ir_uart.h"
#include "tinygl.h"
#include "../fonts/font5x7_1.h"


#define PACER_RATE 500
#define MESSAGE_RATE 10


void display_character (int row, int col)
{
    tinygl_clear();
    tinygl_draw_point (tinygl_point(row,col), 1);
}


int main (void)
{
    int row = 0;
    int col = 0;

    system_init ();
    tinygl_init (PACER_RATE);
    tinygl_font_set (&font5x7_1);
    tinygl_text_speed_set (MESSAGE_RATE);
    navswitch_init ();


    pacer_init (PACER_RATE);

    while (1)
    {
        pacer_wait ();
        tinygl_update ();
        navswitch_update ();

        if (navswitch_push_event_p (NAVSWITCH_NORTH)) {
        }

        if (navswitch_push_event_p (NAVSWITCH_SOUTH)) {
        }

        if (navswitch_push_event_p (NAVSWITCH_EAST)){
            if (row < 4)
                row++;
                display_character(row, col);
        }

        if (navswitch_push_event_p (NAVSWITCH_WEST)){
            if (row > 0) {
                row--;
                display_character(row, col);
            }
        }

        if (navswitch_push_event_p (NAVSWITCH_PUSH)) {
            while (col < 6) {
                col++;
                tinygl_draw_point (tinygl_point(row,col), 100);
            }
        }
    }

    return 0;
}
