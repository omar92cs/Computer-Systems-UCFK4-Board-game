#include <avr/io.h>
#include "system.h"

int main (void)
{

    system_init ();

    DDRC |= (1 << 2); //Setting pin#2 as an output
    DDRD &= ~(1<<7); //Configuring PD7 as an input
    /* Initialise port to drive LED 1.  */


    while (1) //Looping
    {
        if ((PINC |= 0) && (PIND&(1<<7))) { //Checking to see if the white button near R7 was pushed
            PORTC |= (1 << 2); //Turn on the BLUE LED
    }
        /* Turn LED 1 on.  */

        /* TODO.  */

    }
}
