#include <avr/io.h>
#include "system.h"
#include "led.h"


int main (void)
{
    system_init ();
    led_init ();
    TCCR1A = 0x00;
    TCCR1B = 0x05;
    TCCR1C = 0x00;
    /* TODO: Initialise timer/counter1.  */
    while (1)
    {

        /* Turn LED on.  */
        led_set (LED1, 1);

        TCNT1 = 0;

        /* TODO: wait for 500 milliseconds.  */
        while(TCNT1<1953.125){
            continue;
        }
        /* Turn LED off.  */
        led_set (LED1, 0);

        TCNT1=0;

        /* TODO: wait for 500 milliseconds.  */
        while(TCNT1<5859.375){
            continue;
        }

        /* TODO: wait for 500 milliseconds.  */

    }

    //the equation is
    //Say we want it on for 1 third and off for 3 thrids of a second
    //1000ms/4 = 0.250 per quarter.
    //Based on a 8Mhz clock  q = (8×10^6/1024)^-1
    //So 0.250/q = 1953.125 and 0.750/q = 5859.37

}
