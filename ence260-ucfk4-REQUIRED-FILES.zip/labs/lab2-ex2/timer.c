#include <avr/io.h>
#include "timer.h"

/* Initialise timer.  */
void timer_init (void)
{
    /* TODO */
}


/* Wait for the specified length of time.  */
void timer_delay_ms (uint16_t milliseconds)
{
    /* TODO: Calculate the timer/counter value needed 
       for the given number of milliseconds. */
    
    /* TODO: Wait for the timer/couter to reach the 
       value calculated above.  */
}
