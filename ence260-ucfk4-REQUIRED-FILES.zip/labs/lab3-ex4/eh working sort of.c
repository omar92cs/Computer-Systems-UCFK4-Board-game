#include "system.h"
#include "pacer.h"
#include "navswitch.h"
#include "ir_uart.h"
#include "tinygl.h"
#include "../fonts/font5x7_1.h"


#define PACER_RATE 500
#define MESSAGE_RATE 10


void display_character (char character)
{
    char buffer[2];
    buffer[0] = character;
    buffer[1] = '\0';
    tinygl_text (buffer);
}

void display_loser(void) {
    tinygl_text("Hello world");
    tinygl_text_mode_set (TINYGL_TEXT_MODE_SCROLL);
}

int main (void)
{
    system_init ();
    tinygl_init (PACER_RATE);
    tinygl_font_set (&font5x7_1);
    tinygl_text_speed_set (MESSAGE_RATE);
    navswitch_init ();
    char character;
    char character_rec;
    int q = 0;

    /* TODO: Initialise IR driver.  */
    ir_uart_init();

    pacer_init (PACER_RATE);

    static const char options[] = { 'P', 'S', 'R', 'L', 'V' };
    int i = 0;

    while (1)
    {

        tinygl_update();
        navswitch_update();

        if (navswitch_push_event_p (NAVSWITCH_NORTH)) {
            if(i < 4) {
                i++;
            } else {
                i = 0;
            }
            character = options[i];
            display_character(character);
        }

        if (navswitch_push_event_p (NAVSWITCH_SOUTH)) {
            if(i > 0) {
                i--;
            } else {
                i = 4;
            }
            character = options[i];
            display_character(character);
        }

        if (navswitch_push_event_p (NAVSWITCH_PUSH)) {
            ir_uart_putc (options[i]);
        }

        if (ir_uart_read_ready_p ())
        {
            character_rec = ir_uart_getc ();
        }

        if ((character_rec == 'R') && (character == 'S')) {
            display_character('L');
            ir_uart_putc('W');

        }

        if ((q == 0) && (character_rec == 'W')) {
            display_character('W');
        }


    }

    return 0;
}
